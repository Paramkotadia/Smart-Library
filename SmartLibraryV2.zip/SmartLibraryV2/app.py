
from flask import Flask, render_template, request
import cv2
import pytesseract
from PIL import Image
import numpy as np

app = Flask(__name__)
pytesseract.pytesseract.tesseract_cmd = r'C:\\Program Files\\Tesseract-OCR\\tesseract.exe'

def detect_book_from_camera(book_query):
    cap = cv2.VideoCapture(0)
    found = False
    for _ in range(100):  # 100 frames max
        ret, frame = cap.read()
        if not ret:
            break
        gray = cv2.cvtColor(frame, cv2.COLOR_BGR2GRAY)
        text = pytesseract.image_to_string(gray)
        print("[OCR TEXT]:", text.strip())
        if book_query.lower() in text.lower():
            found = True
            break
    cap.release()
    return found

@app.route("/", methods=["GET"])
def index():
    return render_template("index.html", result="")

@app.route("/start", methods=["POST"])
def start():
    book_query = request.form["book_query"]
    result = detect_book_from_camera(book_query)
    return render_template("index.html", result="✅ Book Found!" if result else "❌ Book Not Found.")

if __name__ == "__main__":
    app.run(debug=True)
